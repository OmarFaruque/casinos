@extends('layouts.app-master')

@section('content')
   @include('layouts.partials.login')
@endsection