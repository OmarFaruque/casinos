<?php $__env->startSection('content'); ?>
    <div class="listsconetnt content-center justify-center w-full">
        <div class="grid h-full content-center justify-center">
            <h2 class="text-center bold text-2xl mb-10"><?php echo e(__('New Workers')); ?></h2>
            <div class="flex flex-row w-full m-auto content-item-center h-full justify-center">
                <form 
                    <?php if(Route::is('workers.create')): ?>
                        action="<?php echo e(route('workers.store')); ?>"
                    <?php else: ?> 
                        action="<?php echo e(route('workers.update', $worker)); ?>"
                    <?php endif; ?>   
                    method="post">
                    <?php if(!Route::is('workers.create')): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="grid content-center grid-cols-2 gap-4 w-full justify-center">
                        <div class="">
                            <label for="name"><?php echo e(__('Name')); ?></label>
                            <input type="text" name="name" class="border rounded p-2 mr-2 w-full shadow" id="name" value="<?php echo e(isset($worker) && $worker->name ? $worker->name : ''); ?>">
                        </div>
                        <div class="">
                            <label for="assigned_user"><?php echo e(__('Assigned User')); ?></label>
                            
                            <select name="assigned_user" id="assigned_user" class="border rounded p-2 mr-2 w-full shadow">
                                <option value=""><?php echo e(__('User...')); ?></option>
                                
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($worker) && $user->id == $worker->assigned_user ? 'selected' : ''); ?> value="<?php echo e($user->id); ?>"><?php echo e(!empty($user->display_name) ? $user->display_name : $user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="content-center text-right col-span-2">
                            <input type="submit" class="p-2 cursor-pointer rounded border bg-gray-900 text-gray-200 px-6" value="<?php echo e(Route::is('workers.create') ? __('Submit') : __('Update')); ?>">
                        </div>
                    </div>
                </form>
            </div>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center w-full mt-3 text-red-500"><small><?php echo e($error); ?></small></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/workers/create.blade.php ENDPATH**/ ?>