<?php $__env->startSection('content'); ?>
    <div class="listsconetnt content-center justify-center w-full">
        <div class="grid h-full content-center justify-center">
            <h2 class="text-center bold mb-5"><?php echo e(__('New Workers')); ?></h2>
            <div class="flex flex-row w-full m-auto content-item-center h-full justify-center">
                <form action="<?php echo e(route('workers.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="flex content-center grid-cols-4 gap-4 w-full justify-center">
                        <div class="">
                            <input type="text" name="name" class="border rounded p-2 mr-2 w-full" id="name" value="">
                        </div>
                        <div class="flex content-center">
                            <input type="submit" class="p-2 rounded border bg-gray-900 text-gray-200 px-6" value="<?php echo e(__('Submit')); ?>">
                        </div>
                    </div>
                </form>
            </div>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center w-full mt-3 text-red-500"><small><?php echo e($error); ?></small></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/workers/create.blade.php ENDPATH**/ ?>