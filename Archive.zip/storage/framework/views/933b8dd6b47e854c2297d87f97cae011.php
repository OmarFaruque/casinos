<?php $__env->startSection('content'); ?>
    <div class="listsconetnt content-center justify-center w-full">
        <div class="grid h-full content-center justify-center">
            <h2 class="text-center bold mb-5"><?php echo e(__('New Entry')); ?></h2>
            <div class="grid w-full m-auto content-item-center h-full justify-center">
                <form action="<?php echo e(route('players.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="grid content-center grid-cols-3 gap-10 w-full justify-center">
                        <div class="">
                            <label for="name"><?php echo e(__('Name')); ?></label>
                            <input type="text" name="name" class="border rounded p-2 mr-2 w-full shadow" id="name" value="">
                        </div>
                        <div class="">
                            <label for="date"><?php echo e(__('Date')); ?></label>
                            <input type="date" name="date" class="border rounded p-2 mr-2 w-full shadow" id="date" value="">
                        </div>
                        <div class="">
                            <label for="casino_bonus_lookup"><?php echo e(__('Casino Bonus Lookup')); ?></label>
                            <input type="text" name="casino_bonus_lookup" class="border rounded p-2 mr-2 shadow w-full" id="casino_bonus_lookup" value="">
                        </div>
                        <div class="">
                            <label for="type"><?php echo e(__('Type')); ?></label>
                            
                            <select name="type" id="type" class="border rounded p-2 mr-2 shadow w-full">
                                <option value=""><?php echo e(__('Type...')); ?></option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k); ?>"><?php echo e($type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="">
                            <label for="group"><?php echo e(__('Group')); ?></label>
                            <input type="text" name="group" class="border rounded p-2 mr-2 shadow w-full" id="group" value="">
                        </div>
                        <div class="">
                            <label for="payment_method"><?php echo e(__('Payment Method')); ?></label>
                            <select class="border rounded p-2 mr-2 shadow w-full" name="payment_method" id="payment_method">
                                <option value=""><?php echo e(__('Payment Method...')); ?></option>
                                <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $pmethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($s); ?>"><?php echo e($pmethod); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="">
                            <label for="deposit"><?php echo e(__('Deposit')); ?></label>
                            <input type="number" name="deposit" class="border rounded p-2 mr-2 shadow w-full" id="deposit" value="">
                        </div>
                        <div class="">
                            <label for="bonus"><?php echo e(__('Bonus')); ?></label>
                            <input type="number" name="bonus" class="border rounded p-2 mr-2 shadow w-full" id="bonus" value="">
                        </div>
                        <div class="">
                            <label for="balance"><?php echo e(__('Balance')); ?></label>
                            <input type="number" name="balance" class="border rounded p-2 mr-2 shadow w-full" id="balance" value="">
                        </div>
                        <div class="">
                            <label for="status"><?php echo e(__('Status')); ?></label>
                            <select name="status" id="status" class="border rounded p-2 mr-2 shadow w-full" >
                                <?php $__currentLoopData = $status_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k); ?>"><?php echo e($status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="">
                            <label for="partpaid"><?php echo e(__('Part Paid')); ?></label>
                            <input type="number" name="partpaid" class="border rounded p-2 mr-2 shadow w-full" id="partpaid" value="">
                        </div>
                        <div class="">
                            <label for="fainalpaid"><?php echo e(__('Fainal Paid')); ?></label>
                            <input type="number" name="fainalpaid" class="border rounded p-2 mr-2 shadow w-full" id="fainalpaid" value="">
                        </div>

                        <div class="">
                            
                            <label for="game_played"><?php echo e(__('Game Played')); ?></label>
                            <select name="game_played" id="game_played" class="border rounded p-2 mr-2 shadow w-full">
                                <option value=""><?php echo e(__('Select a slot')); ?></option>
                                <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($slot->id); ?>"><?php echo e($slot->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="">
                            <label for="spin"><?php echo e(__('Spin')); ?></label>
                            <input type="number" name="spin" class="border rounded p-2 mr-2 shadow w-full" id="spin" value="">
                        </div>

                        <div class="">
                            <label for="rtp"><?php echo e(__('RTP (%)')); ?></label>
                            <input type="number" name="rtp" class="border rounded p-2 mr-2 shadow w-full" id="rtp" min="0" max="100" value="">
                        </div>

                        <div class="">
                            <label for="worker"><?php echo e(__('Worker')); ?></label>
                            <select name="worker" id="worker" class="border rounded p-2 mr-2 shadow w-full" >
                                <option value=""><?php echo e(__('Select a Worker')); ?></option>
                                <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($worker->id); ?>"><?php echo e($worker->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-span-2">
                            <label for="notes"><?php echo e(__('Notes')); ?></label>
                            <input type="text" name="notes" class="border rounded p-2 mr-2 shadow w-full" id="notes" value="">
                        </div>
                    </div>
                </form>
            </div>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center w-full mt-3 text-red-500"><small><?php echo e($error); ?></small></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/casinodone/create.blade.php ENDPATH**/ ?>