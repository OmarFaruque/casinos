<?php $__env->startSection('content'); ?>
    <div class="listsconetnt content-center justify-center w-full">
        <div class="grid h-full content-center justify-center">
            <h2 class="text-center bold mb-5"><?php echo e(__('New Entry')); ?></h2>
            <div class="grid w-full m-auto content-item-center h-full justify-center">
                <form
                    <?php if(Route::is('new-casino-done')): ?>
                        action="<?php echo e(route('players.store')); ?>"
                    <?php else: ?> 
                        action="<?php echo e(route('players.update', $done)); ?>"
                    <?php endif; ?>   
                    
                    method="post">
                    <?php echo csrf_field(); ?>
                    <?php if(!Route::is('new-casino-done')): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>

                    <div class="grid content-center grid-cols-3 gap-10 w-full justify-center">
                        <div class="">
                            <label for="name"><?php echo e(__('Name')); ?></label>
                            <select name="name" id="name" class="h-11 border rounded p-2 mr-2 shadow w-full <?php echo e($errors->get('name') ? 'border-orange-600' : ''); ?>">
                                <option value=""><?php echo e(__('Name...')); ?></option>
                                <?php $__currentLoopData = $gnomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($done) && $done->name == $name->id ? 'selected' : ''); ?>  value="<?php echo e($name->id); ?>"><?php echo e($name->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                        <div class="">
                            <label for="date"><?php echo e(__('Date')); ?></label>
                            <input type="date" name="date" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('date') ? 'border-orange-600' : ''); ?>" id="date" value="<?php echo e(isset($done) ? $done->date : ''); ?>">
                        </div>
                        <div class="">
                            <label for="casino_bonus_lookup"><?php echo e(__('Casino Bonus Lookup')); ?></label>
                            <select name="casino_bonus_lookup" id="casino_bonus_lookup" class="h-11 border rounded p-2 mr-2 shadow w-full <?php echo e($errors->get('casino_bonus_lookup') ? 'border-orange-600' : ''); ?>">
                                <option value=""><?php echo e(__('Lookup...')); ?></option>
                                <?php $__currentLoopData = $bonuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $bonus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($done) && $done->casino_bonus_lookup == $bonus->id ? 'selected' : ''); ?>  value="<?php echo e($bonus->id); ?>"><?php echo e($bonus->casino_lookup); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="">
                            <label for="type"><?php echo e(__('Type')); ?></label>
                            <select name="type" id="type" class="border rounded p-2 mr-2 h-11 shadow w-full <?php echo e($errors->get('type') ? 'border-orange-600' : ''); ?>">
                                <option value=""><?php echo e(__('Type...')); ?></option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($done) && $done->type == $k ? 'selected' : ''); ?> value="<?php echo e($k); ?>"><?php echo e($type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="">
                            <label for="casino"><?php echo e(__('Casino')); ?></label>
                            <select name="casino" id="casino" class="border rounded p-2 mr-2 h-11 shadow w-full <?php echo e($errors->get('casino') ? 'border-orange-600' : ''); ?>">
                                <option value=""><?php echo e(__('Select casino...')); ?></option>
                                <?php $__currentLoopData = $casinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $casino): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($done) && $done->casino == $casino->id ? 'selected' : ''); ?> value="<?php echo e($casino->id); ?>"><?php echo e($casino->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="">
                            <label for="group"><?php echo e(__('Group')); ?></label>
                            <select name="group" id="group" class="border rounded p-2 h-11 mr-2 shadow w-full">
                                <option value=""><?php echo e(__('Select a group...')); ?></option>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($done) && $done->group == $group->id ? 'selected' : ''); ?> value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="">
                            <label for="payment_method"><?php echo e(__('Payment Method')); ?></label>
                            <select class="border rounded p-2 mr-2 shadow w-full h-11" name="payment_method" id="payment_method">
                                <option value=""><?php echo e(__('Payment Method...')); ?></option>
                                <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $pmethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($done) && $done->payment_method == $s ? 'selected' : ''); ?> value="<?php echo e($s); ?>"><?php echo e($pmethod); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="">
                            <label for="deposit"><?php echo e(__('Deposit')); ?></label>
                            <input type="number" name="deposit" class="border rounded p-2 mr-2 shadow w-full" id="deposit" value="<?php echo e(isset($done) ? $done->deposit : ''); ?>">
                        </div>
                        <div class="">
                            <label for="bonus"><?php echo e(__('Bonus')); ?></label>
                            <input type="number" name="bonus" class="border rounded p-2 mr-2 shadow w-full" id="bonus" value="<?php echo e(isset($done) ? $done->bonus : ''); ?>">
                        </div>
                        <div class="">
                            <label for="balance"><?php echo e(__('Balance')); ?></label>
                            <input type="number" name="balance" class="border rounded p-2 mr-2 shadow w-full" id="balance" value="<?php echo e(isset($done) ? $done->balance : ''); ?>">
                        </div>
                        <div class="">
                            <label for="status"><?php echo e(__('Status')); ?></label>
                            <select name="status" id="status" class="border rounded h-11 p-2 mr-2 shadow w-full" >
                                <?php $__currentLoopData = $status_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(isset($done) && $done->status == $k ? 'selected' : ''); ?> value="<?php echo e($k); ?>"><?php echo e($status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="">
                            <label for="partpaid"><?php echo e(__('Part Paid')); ?></label>
                            <input type="number" name="partpaid" class="border rounded p-2 mr-2 shadow w-full" id="partpaid" value="<?php echo e(isset($done) ? $done->partpaid : ''); ?>">
                        </div>
                        <div class="">
                            <label for="fainalpaid"><?php echo e(__('Fainal Paid')); ?></label>
                            <input type="number" name="fainalpaid" class="border rounded p-2 mr-2 shadow w-full" id="fainalpaid" value="<?php echo e(isset($done) ? $done->fainalpaid : 0); ?>">
                        </div>

                        <div class="">
                            
                            <label for="game_played"><?php echo e(__('Game Played')); ?></label>
                            <select name="game_played" id="game_played" class="h-11 border rounded p-2 mr-2 shadow w-full">
                                <option value=""><?php echo e(__('Select a slot')); ?></option>
                                <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($done) && $done->game_played == $slot->id ? 'selected' : ''); ?> value="<?php echo e($slot->id); ?>"><?php echo e($slot->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="">
                            <label for="spin"><?php echo e(__('Spin')); ?></label>
                            <input type="number" name="spin" class="border rounded p-2 mr-2 shadow w-full" id="spin" value="<?php echo e(isset($done) ? $done->spin : ''); ?>">
                        </div>

                        <div class="">
                            <label for="rtp"><?php echo e(__('RTP (%)')); ?></label>
                            <input type="number" name="rtp" class="border rounded p-2 mr-2 shadow w-full" id="rtp" min="0" max="100" value="<?php echo e(isset($done) ? $done->rtp : ''); ?>">
                        </div>

                        <div class="col-span-2">
                            <label for="worker"><?php echo e(__('Worker')); ?></label>
                            <select name="worker" id="worker" class="h-11 border rounded p-2 mr-2 shadow w-full" >
                                <option value=""><?php echo e(__('Select a Worker')); ?></option>
                                <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($done) && $done->worker == $worker->id ? 'selected':''); ?> value="<?php echo e($worker->id); ?>"><?php echo e($worker->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-span-3">
                            <label for="notes"><?php echo e(__('Notes')); ?></label>
                            <input type="text" name="notes" class="border rounded p-2 mr-2 shadow w-full" id="notes" value="<?php echo e(isset($done) ? $done->notes : ''); ?>">
                        </div>
                        <div class="flex items-end">
                            <button type="submit" class="btn justify-end py-2 hover:bg-gray-900 hover:text-gray-50 transition  border px-5 rounded-md"><?php echo e(Route::is('new-casino-done') ? __('Submit') : __('Update')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/casinodone/create.blade.php ENDPATH**/ ?>