<?php $__env->startSection('content'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <div class="bg-light rounded w-full">
        <?php if(auth()->guard()->guest()): ?>
            <?php echo $__env->make('layouts.partials.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
            <div class="wrap min-w-full">
                <div class="grid grid-cols-1 p-10 gap-10">
                    <div class="w-full rounded shadow-md px-8 py-10 bg-slate-100">
                        <h1 class="text-2xl"><?php echo e(__('Profit & EV')); ?></h1>
                        <canvas class="w-full" id="profitChart" data-profits=<?php echo e($profits); ?>></canvas>
                    </div>  
                </div>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home/index.blade.php ENDPATH**/ ?>