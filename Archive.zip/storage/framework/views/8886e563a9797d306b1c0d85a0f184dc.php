<?php $__env->startSection('content'); ?>
    <div class="listsconetnt w-full px-5 py-8">
        <a class="bg-gray-200 py-3 px-5 rounded text-gray-900 hover:text-gray-200 hover:bg-gray-900" href="<?php echo e(route('workers.create')); ?>"><?php echo e(__('Create')); ?></a>

        <div class="w-2/4 m-auto mt-9 justify-center">
            <table class="table-auto w-full rounded-md">
                <thead class="bg-gray-50 border-b-2 border-gray-200">
                    <tr class="border-bottom">
                        <th class="p-2 text-left">SL</th>
                        <th class="text-left p-2"><?php echo e(__('Name')); ?></th>
                        <th class="text-left p-2"><?php echo e(__('Action')); ?></th>
                    </tr>
                    <tbody>
                         <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($k % 2 == 0 ? 'bg-gray-50' : ''); ?>">
                                <td class="p-2"><?php echo e($k + 1); ?></td>
                                <td class="p-2"><?php echo e($worker->name); ?></td>
                                <td class="p-2">
                                    <a class="btn px-5 py-2 border rounded hover:bg-gray-900 hover:text-gray-100" href="#"><?php echo e(__('Delete')); ?></a>
                                </td>
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </thead>
    
            </table>
        </div>
    </div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/workers/lists.blade.php ENDPATH**/ ?>