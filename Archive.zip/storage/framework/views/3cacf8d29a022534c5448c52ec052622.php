<?php $__env->startSection('content'); ?>
    <div class="listsconetnt content-center justify-center w-full">
        <div class="grid h-full content-center justify-center">
            <h2 class="text-center bold mb-5 text-2xl"><strong><?php echo e(__('New Group')); ?></strong></h2>
            <div class="grid w-full m-auto content-item-center h-full justify-center">
                <form 
                    <?php if(Route::is('casinos.create')): ?>
                        action="<?php echo e(route('casinos.store')); ?>"
                    <?php else: ?> 
                        action="<?php echo e(route('casinos.update', $casino)); ?>"
                    <?php endif; ?>   
                
                    method="post">
                    <?php if(!Route::is('casinos.create')): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="grid content-center grid-cols-3 gap-10 w-full justify-center">
                        <div class="col-span-2">
                            <label for="name"><?php echo e(__('Name')); ?></label>
                            <input type="text" name="name" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('name') ? 'border-orange-600' : ''); ?>" id="name" value="<?php echo e(isset($casino) && $casino->name ? $casino->name : ''); ?>">
                            <?php if($errors->get('name')): ?> <div class="text-orange-600"><small><?php echo e($errors->first('name')); ?></small></div> <?php endif; ?>
                        </div>
                        <div class="flex items-end">
                            <button type="submit" class="btn justify-end py-2 hover:bg-gray-900 hover:text-gray-50 transition  border px-5 rounded-md"><?php echo e(Route::is('casinos.create') ? __('Submit') : __('Update')); ?></button>
                        </div>
                    </div>  
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/casino/create.blade.php ENDPATH**/ ?>