<!doctype html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.87.0">
    <title><?php echo e(__('Casino')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

</head>
<body class="overflow-x-hidden">
    
    <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="mx-auto min-h-screen  w-full overflow-y-hidden <?php echo e(!auth()->user() ? 'justify-center' : ''); ?>">
        <div class="flex overflow-x-hidden">
            <?php if(auth()->guard()->check()): ?>
                <div style="min-width: 200px;" class="bg-dark position-relative relative text-white bg-gray-800 top-0 left-0 z-40 w-64 min-h-screen h-full p-4 overflow-y-auto transition-transform -translate-x-half dark:bg-gray-800 table-cell">
                    <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php endif; ?>
            <div class="block overflow-x-hidden">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        
    </main>
      
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
  </body>
</html><?php /**PATH /var/www/html/resources/views/layouts/app-master.blade.php ENDPATH**/ ?>