<!doctype html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.87.0">
    <title>Fixed top navbar example · Bootstrap v5.1</title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

</head>
<body>
    
    <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="mx-auto flex <?php echo e(!auth()->user() ? 'justify-center' : ''); ?>">
        <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->yieldContent('content'); ?>
        
    </main>
      
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
  </body>
</html><?php /**PATH /var/www/html/resources/views/layouts/app-master.blade.php ENDPATH**/ ?>