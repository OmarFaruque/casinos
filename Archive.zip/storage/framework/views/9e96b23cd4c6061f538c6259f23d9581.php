<?php $__env->startSection('content'); ?>
    <div class="listsconetnt w-full px-5 py-8">
        <div class="w-2/4 m-auto mt-9 justify-center">
            <?php if(session('success')): ?>
                <div class="alert px-6 py-3 bg-blue-400 text-white mb-3 rounded"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <div class="table shadow-md rounded-md">
                    <div class="slotWrap border table-header-group rounded-md">
                        <div class="header text-gray-800 bg-gray-200 px-6 py-2 table-row">
                            <div class="px-2 py-3 flex-auto w-1/4 table-cell"><?php echo e(__('Date')); ?></div>
                            <div class="px-2 py-3 flex-auto w-1/6 table-cell"><?php echo e(__('Profit')); ?></div>
                            <div class="px-2 py-3 flex-auto w-1/4 table-cell"><?php echo e(__('Profit+')); ?></div>
                            <div class="px-2 py-3 flex-auto w-1/4 table-cell"><?php echo e(__('Bonuses')); ?></div>
                            <div class="px-2 py-3 flex-auto w-1/4 table-cell"><?php echo e(__('EV')); ?></div>
                            <div class="px-2 py-3 flex-auto w-1/4 table-cell"><?php echo e(__('EV+')); ?></div>
                            <div class="px-2 py-3 flex-auto w-1/4 table-cell"><?php echo e(__('Reloads')); ?></div>
                            <div class="px-2 py-3 flex-auto w-1/4 table-cell"><?php echo e(__('SUBs')); ?></div>
                        </div>
                    </div>
                    <div class="body table-row-group">
                        <?php 
                            $profit_plus =  $profits && isset($profits[0]) ? $profits[0]->profit : 0; 
                            $ev_plus = 0;
                        ?>
                        
                        <?php $__currentLoopData = $profits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $profit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                if($k > 0){
                                    $profit_plus += $profit->profit; 
                                    $ev_plus = $ev_plus + ($profit->total_bonus * 0.45);
                                }
                            ?>
                            <div class="singleslot px-6 py-2 table-row">
                                <div class="px-2 table-cell py-3 flex-auto w-1/4"><?php echo e($profit->date); ?></div>
                                <div class="px-2 py-3 table-cell gap-4 flex-auto w-1/4"><?php echo e($profit->profit); ?></div>
                                <div class="px-2 py-3 table-cell gap-4 flex-auto w-1/4"><?php echo e($profit_plus); ?></div>
                                <div class="px-2 py-3 table-cell gap-4 flex-auto w-1/4"><?php echo e($profit->total_bonus); ?></div>
                                <div class="px-2 py-3 table-cell gap-4 flex-auto w-1/4"><?php echo e($profit->total_bonus * 0.45); ?></div>
                                <div class="px-2 py-3 table-cell gap-4 flex-auto w-1/4"><?php echo e($ev_plus + ($profit->total_bonus * 0.45)); ?></div>
                                <div class="px-2 py-3 table-cell gap-4 flex-auto w-1/4"><?php echo e($profit->reload); ?></div>
                                <div class="px-2 py-3 table-cell gap-4 flex-auto w-1/4"><?php echo e($profit->sub); ?></div>
                            </div>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            </div>
        </div>
    </div>


   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/profit/lists.blade.php ENDPATH**/ ?>