<?php $__env->startSection('content'); ?>
    <div class="listsconetnt content-center justify-center w-full">
        <div class="grid h-full content-center justify-center">
            <h2 class="text-center bold mb-5 text-2xl"><strong><?php echo e(__('New Slot')); ?></strong></h2>
            <div class="grid w-full m-auto content-item-center h-full justify-center">
                <form 
                    <?php if(Route::is('slot.create')): ?>
                        action="<?php echo e(route('slot.store')); ?>"
                    <?php else: ?> 
                        action="<?php echo e(route('slot.update', $slot)); ?>"
                    <?php endif; ?>   
                
                    method="post">
                    <?php if(!Route::is('slot.create')): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="grid content-center grid-cols-3 gap-10 w-full justify-center">
                        <div class="">
                            <label for="name"><?php echo e(__('Name')); ?></label>
                            <input type="text" name="name" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('name') ? 'border-orange-600' : ''); ?>" id="name" value="<?php echo e(isset($slot) && $slot->name ? $slot->name : ''); ?>">
                            <?php if($errors->get('name')): ?> <div class="text-orange-600"><small><?php echo e($errors->first('name')); ?></small></div> <?php endif; ?>
                        </div>
                        <div class="">
                            <label for="he"><?php echo e(__('HE')); ?></label>
                            <input type="number" step="0.01" min="0" max="100" name="he" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('he') ? 'border-orange-600' : ''); ?>" id="he" value="<?php echo e(isset($slot) && $slot->he ? $slot->he : ''); ?>">
                            <?php if($errors->get('he')): ?> <div class="text-orange-600"><small><?php echo e($errors->first('he')); ?></small></div> <?php endif; ?>
                        </div>
                        <div class="">
                            <label for="provider"><?php echo e(__('Provider')); ?></label>
                            <input type="text" name="provider" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('provider') ? 'border-orange-600' : ''); ?>" id="provider" value="<?php echo e(isset($slot) && $slot->provider ? $slot->provider : ''); ?>">
                            <?php if($errors->get('provider')): ?> <div class="text-orange-600"><small><?php echo e($errors->first('provider')); ?></small></div> <?php endif; ?>
                        </div>
                        <div class="col-span-3 flex justify-end">
                            <button type="submit" class="btn justify-end py-2 hover:bg-gray-900 hover:text-gray-50 transition  border px-5 rounded-md"><?php echo e(Route::is('slot.create') ? __('Submit') : __('Update')); ?></button>
                        </div>
                    </div>  
                </form>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/slot/create.blade.php ENDPATH**/ ?>