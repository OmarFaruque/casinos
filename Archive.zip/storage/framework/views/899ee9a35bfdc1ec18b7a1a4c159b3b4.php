<?php $__env->startSection('content'); ?>
    <div class="listsconetnt content-center justify-center w-full">
        <div class="grid h-full content-center justify-center">
            <h2 class="text-center bold mb-5 text-2xl"><strong>
                <?php if(Route::is('bans.create')): ?>
                    <?php echo e(__('New Ban')); ?>

                <?php else: ?>
                    <?php echo e(__('Update Ban')); ?>

                <?php endif; ?>
            </strong></h2>
            <div class="grid w-full m-auto content-item-center h-full justify-center">
                <form 
                    <?php if(Route::is('bans.create')): ?>
                        action="<?php echo e(route('bans.store')); ?>"
                    <?php else: ?> 
                        action="<?php echo e(route('bans.update', $bans)); ?>"
                    <?php endif; ?>   
                
                    method="post">
                    <?php if(!Route::is('bans.create')): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="grid content-center grid-cols-3 gap-10 w-full justify-center">
                        <div class="">
                            <label for="gnome"><?php echo e(__('Gnome')); ?></label>
                            <select id="gnome" name="gnome" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('gnome') ? 'border-orange-600' : ''); ?>">
                                <option value=""><?php echo e(__('Select Gnome...')); ?></option>
                                <?php $__currentLoopData = $gnomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gnome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($bans) && $gnome->id == $bans->gnome ? 'selected' : ''); ?> value="<?php echo e($gnome->id); ?>"><?php echo e($gnome->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->get('gnome')): ?> <div class="text-orange-600"><small><?php echo e($errors->first('gnome')); ?></small></div> <?php endif; ?>
                        </div>

                        <div class="">
                            <label for="casino"><?php echo e(__('Casino')); ?></label>
                            <select id="casino" name="casino" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('casino') ? 'border-orange-600' : ''); ?>">
                                <option value=""><?php echo e(__('Select Casino...')); ?></option>
                                <?php $__currentLoopData = $casinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casino): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($bans) && $casino->id == $bans->casino ? 'selected' : ''); ?> value="<?php echo e($casino->id); ?>"><?php echo e($casino->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->get('casino')): ?> <div class="text-orange-600"><small><?php echo e($errors->first('casino')); ?></small></div> <?php endif; ?>
                        </div>
                        <div class="">
                            <label for="group"><?php echo e(__('Group')); ?></label>
                            <select id="group" name="group" class="border rounded p-2 mr-2 w-full shadow">
                                <option value=""><?php echo e(__('Select Group...')); ?></option>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($bans) && $group->id == $bans->group ? 'selected' : ''); ?> value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-span-3 flex justify-end">
                            <button type="submit" class="btn justify-end py-2 hover:bg-gray-900 hover:text-gray-50 transition  border px-5 rounded-md"><?php echo e(Route::is('bans.create') ? __('Submit') : __('Update')); ?></button>
                        </div>
                    </div>  
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/bans/create.blade.php ENDPATH**/ ?>