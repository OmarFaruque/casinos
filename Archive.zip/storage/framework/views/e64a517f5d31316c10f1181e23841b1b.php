<?php $__env->startSection('content'); ?>
    <div class="flex justify-center h-100 content-center items-center min-h-screen mx-auto w-4/6">
        <div class="border p-10 rounded shadow-md w-2/5 center-center">
            <form method="post" 
                <?php if(Route::is('register.show')): ?>
                    action="<?php echo e(route('register.perform')); ?>"
                <?php else: ?> 
                    action="<?php echo e(route('register.update', $user)); ?>"
                <?php endif; ?>   
                >
                <?php if(!Route::is('register.show')): ?>
                    <?php echo method_field('PATCH'); ?>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <h1 class="h3 text-2xl fw-normal text-center mb-6"><?php echo e(Route::is('register.show') ? __('Register New User') : __('Update User Information')); ?></h1>
        
                <div class="form-group form-floating mb-3">
                    <input type="email" <?php echo e(isset($user) ? 'disabled' : ''); ?> class="form-control block w-full rounded border p-2" name="email" value="<?php echo e(isset($user) && $user->email ? $user->email : old('email')); ?>" placeholder="name@example.com" required="required" autofocus>
                    <label for="floatingEmail"><small><?php echo e(__('Email address')); ?></small></label>
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                </div>
        
                <div class="form-group form-floating mb-3">
                    <input type="text" class="form-control block w-full rounded border p-2" name="username" value="<?php echo e(isset($user) && $user->name ? $user->name : old('username')); ?>" placeholder="Username" required="required" autofocus>
                    <label for="floatingName"><small>Username</small></label>
                    <?php if($errors->has('username')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group form-floating mb-3">
                    <input type="text" class="form-control block w-full rounded border p-2" name="display_name" value="<?php echo e(isset($user) && $user->display_name ? $user->display_name : old('display_name')); ?>" placeholder="Name.." required="required" autofocus>
                    <label for="floatingName"><small><?php echo e(__('Display name')); ?></small></label>
                    <?php if($errors->has('display_name')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('display_name')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group form-floating mb-3">
                    <select name="role" id="user_role" class="border rounded p-2 mr-2 w-full shadow">
                        <option value=""><?php echo e(__('User...')); ?></option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(isset($user) && $user->role == $k ? 'selected' : ''); ?> value="<?php echo e($k); ?>"><?php echo e($role); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="user_role"><small><?php echo e(__('Role')); ?></small></label>
                </div>

                <div class="form-group form-floating mb-3">
                    <input type="password" class="form-control block w-full rounded border p-2" name="password" value="" autocomplete="new-password" placeholder="Password" <?php echo e(Route::is('register.show') ? 'required="required"': ''); ?>>
                    <label for="floatingPassword"><small>Password</small></label>
                    <?php if($errors->has('password')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                </div>
                <?php if(Route::is('register.show')): ?>
                <div class="form-group form-floating mb-3">
                    <input type="password" class="form-control block w-full rounded border p-2" name="password_confirmation" value="" placeholder="Confirm Password" <?php echo e(Route::is('register.show') ? 'required="required"': ''); ?>>
                    <label for="floatingConfirmPassword"><small><?php echo e(__('Confirm Password')); ?></small></label>
                    <?php if($errors->has('password_confirmation')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('password_confirmation')); ?></span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
        
                <button class="w-8 bg-blue-100 p-2 mt-5" type="submit"><small><?php echo e(Route::is('register.show') ? __('Register') : __('Update')); ?></small></button>
                
            </form>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/auth/register.blade.php ENDPATH**/ ?>