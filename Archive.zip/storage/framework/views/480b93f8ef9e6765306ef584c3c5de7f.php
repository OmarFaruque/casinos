<?php $__env->startSection('content'); ?>
    <div class="listsconetnt w-full px-5 py-8">
        <div class="w-full m-auto mt-9">
            <?php if(session('success')): ?>
                <div class="alert px-6 py-3 bg-blue-400 text-white mb-3 rounded"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <div class="slotWrap w-full mx-auto">
                <div class="grid grid-cols-2 gap-10">
                    <div class="">
                        <h2 class="mb-5 font-normal text-2xl"><?php echo e(__('Statistics')); ?></h2>
                        <form action="<?php echo e(route('overview.index')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="grid gap-6 grid-cols-3 items-end mb-8">
                                <div class="">
                                    <label for="from"><?php echo e(__('From')); ?></label>
                                    <input type="date" name="from" id="from" class="border rounded w-full px-2 py-3 shadow" value=<?php echo e(old('from')); ?>>
                                </div>
                                <div class="">
                                    <label for="to"><?php echo e(__('To')); ?></label>
                                    <input type="date" name="to" id="to" class="border rounded w-full px-2 py-3 shadow" value=<?php echo e(old('to')); ?>>
                                </div>
                                <div class="">
                                    <input type="submit" class="px-5 py-3 border rounded w-4/6 bg-slate-600 shadow text-cyan-100 cursor-pointer hover:bg-slate-800 hover:text-cyan-50" value="<?php echo e(__('Submit')); ?>">
                                </div>
                            </div>
                        </form>
                        <div class="body grid gap-6 grid-cols-3">
                            <div class="shadow flex rounded px-5 items-center py-6 justify-between bg-slate-100">
                                <h3><strong><?php echo e(__('Total Owed')); ?></strong></h3>
                                <div><span><?php echo e($casino_dones->total_owed); ?></span></div>
                            </div>
                            <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                                <h3><strong><?php echo e(__('Projected Monthly')); ?></strong></h3>
                                <span><?php echo e(number_format($monthly_ev, 2)); ?></span>
                            </div>
                            <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                                <h3><strong><?php echo e(__('Realised Profit')); ?></strong></h3>
                                <span><?php echo e(number_format($casino_dones->total_profit - $casino_dones ->total_owed, 2)); ?></span>
                            </div>
                            <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                                <h3><strong><?php echo e(__('EV')); ?></strong></h3>
                                <span><?php echo e($casino_dones->bonus_ev); ?></span>
                            </div>
                            <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                                <h3><strong><?php echo e(__('Bonuses Done')); ?></strong></h3>
                                <span><?php echo e($casino_dones->bonus_done); ?></span>
                            </div>
                            <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                                <h3><strong><?php echo e(__('Bonus Value')); ?></strong></h3>
                                <span><?php echo e($casino_dones->total_bonus); ?></span>
                            </div>
                            <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                                <h3><strong><?php echo e(__('Profit')); ?></strong></h3>
                                <span><?php echo e($casino_dones->total_profit); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="">
                        <h2 class="mb-5 font-normal text-2xl"><?php echo e(__('Chart View')); ?></h2>
                        <div class="p-3 bg-slate-100 shadow rounded">
                            <canvas class="w-full" id="profitChart" data-profits=<?php echo e($charts); ?>></canvas>
                        </div>
                    </div>
                </div>

                <br>
                <h2 class="text-2xl mt-7 mb-2"><?php echo e(__('All Workers Last '.count($sevens).' days')); ?></h2>
                <div class="table w-full border rounded-md shadow-md">
                    <div class="table-header-group bg-slate-200">
                        <div class="table-row">
                            <div class="table-cell p-5"></div>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div class="table-cell p-3"><?php echo e(date('d-M', strtotime($single->date))); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"> <?php echo e(__('Last '.count($sevens).' days')); ?></div>
                        </div>
                    </div>
                    <div class="table-row-group">
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('Bonus Value')); ?></div>
                            <?php $total_bonus_value = 0; ?>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="table-cell p-3"><?php echo e($single->bonus_value); ?></div>
                                <?php $total_bonus_value += $single->bonus_value; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_bonus_value); ?></div>
                        </div>
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('Bonuses Done')); ?></div>
                            <?php $total_bonus_done = 0; ?>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="table-cell p-3"><?php echo e($single->bonus_done); ?></div>
                                <?php $total_bonus_done += $single->bonus_done; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_bonus_done); ?></div>
                        </div>
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('EV')); ?></div>
                            <?php $total_bonus_ev = 0; ?>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="table-cell p-3"><?php echo e($single->bonus_ev); ?></div>
                                <?php $total_bonus_ev += $single->bonus_ev; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_bonus_ev); ?></div>
                        </div>
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('Profit')); ?></div>
                            <?php $total_profit = 0; ?>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="table-cell p-3"><?php echo e($single->bonus_profit); ?></div>
                                <?php $total_profit += $single->bonus_profit; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_profit); ?></div>
                        </div>
                    </div>
                </div>




                
                <?php $__currentLoopData = $groupreports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($worker->reports) <= 0): ?> <?php continue; ?> <?php endif; ?>
                <br>
                <div class="flex justify-between  mt-7 mb-2">
                    <div><h2 class="text-2xl"><?php echo e($worker->name); ?></h2></div>
                    <div><h3><strong><?php echo e(__('Owed')); ?>: <?php echo e($worker->total_owed); ?></strong></h3></div>
                </div>
                
                <div class="table w-full border rounded-md shadow-md">
                    <div class="table-header-group bg-slate-200">
                        <div class="table-row">
                            <div class="table-cell p-5"></div>
                            <?php $__currentLoopData = $worker->reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div class="table-cell p-3"><?php echo e(date('d-M', strtotime($single->date))); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"> <?php echo e(__('Last '.count($worker->reports).' days')); ?></div>
                        </div>
                    </div>
                    <div class="table-row-group">
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('Bonus Value')); ?></div>
                            <?php $total_bonus_value = 0; ?>
                            <?php $__currentLoopData = $worker->reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="table-cell p-3"><?php echo e($single->bonus_value); ?></div>
                                <?php $total_bonus_value += $single->bonus_value; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_bonus_value); ?></div>
                        </div>
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('Bonuses Done')); ?></div>
                            <?php $total_bonus_done = 0; ?>
                            <?php $__currentLoopData = $worker->reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="table-cell p-3"><?php echo e($single->bonus_done); ?></div>
                                <?php $total_bonus_done += $single->bonus_done; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_bonus_done); ?></div>
                        </div>
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('EV')); ?></div>
                            <?php $total_bonus_ev = 0; ?>
                            <?php $__currentLoopData = $worker->reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="table-cell p-3"><?php echo e($single->bonus_ev); ?></div>
                                <?php $total_bonus_ev += $single->bonus_ev; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_bonus_ev); ?></div>
                        </div>
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('Profit')); ?></div>
                            <?php $total_profit = 0; ?>
                            <?php $__currentLoopData = $worker->reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="table-cell p-3"><?php echo e($single->bonus_profit); ?></div>
                                <?php $total_profit += $single->bonus_profit; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_profit); ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/overview/index.blade.php ENDPATH**/ ?>