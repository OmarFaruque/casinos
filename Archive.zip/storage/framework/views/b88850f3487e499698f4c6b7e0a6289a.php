<?php $__env->startSection('content'); ?>
    <div class="listsconetnt w-full px-5 py-8">
        <a class="bg-gray-200 py-3 px-5 rounded text-gray-900 hover:text-gray-200 hover:bg-gray-900" href="<?php echo e(route('new-casino-done')); ?>"><?php echo e(__('New Entry')); ?></a>

        <div class="w-2/4 m-auto mt-9 justify-center">
            <table class="table-auto w-full rounded-md">
                <thead class="bg-gray-50 border-b-2 border-gray-200">
                    <tr class="border-bottom">
                        <th class="p-2 text-left">SL</th>
                        <th class="text-left p-2"><?php echo e(__('Name')); ?></th>
                        <th class="text-left p-2"><?php echo e(__('Action')); ?></th>
                    </tr>
                    <tbody>
                         
                    </tbody>
                </thead>
    
            </table>
        </div>
    </div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/casinodone/lists.blade.php ENDPATH**/ ?>