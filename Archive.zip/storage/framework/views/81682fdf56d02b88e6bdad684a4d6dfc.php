<?php $__env->startSection('content'); ?>
    <div class="listsconetnt w-full px-5 py-8">
        <a class="bg-gray-200 py-3 px-5 rounded text-gray-900 hover:text-gray-200 hover:bg-gray-900" href="<?php echo e(route('casinos-done')); ?>"><?php echo e(__('Casinodne Lists')); ?></a>
        <div class="w-full m-auto mt-9">
            <?php if(session('success')): ?>
                <div class="alert px-6 py-3 bg-blue-400 text-white mb-3 rounded"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <div class="slotWrap w-5/6 mx-auto">
                <h2 class="mb-5 font-normal text-2xl"><?php echo e(__('Statistics')); ?></h2>
                <div class="body grid gap-6 grid-cols-3">
                    <div class="shadow flex rounded px-5 items-center py-6 justify-between bg-slate-100">
                        <h3><strong><?php echo e(__('Total Owed')); ?></strong></h3>
                        <div><span><?php echo e($casino_dones->total_owed); ?></span></div>
                    </div>
                    <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                        <h3><strong><?php echo e(__('Projected Monthly EV')); ?></strong></h3>
                        <span><?php echo e(0); ?></span>
                    </div>
                    <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                        <h3><strong><?php echo e(__('Projected Monthly Bonuses')); ?></strong></h3>
                        <span><?php echo e(0); ?></span>
                    </div>
                    <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                        <h3><strong><?php echo e(__('Part Payments')); ?></strong></h3>
                        <span><?php echo e($casino_dones->total_partpaid); ?></span>
                    </div>
                    <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                        <h3><strong><?php echo e(__('In Dispute')); ?></strong></h3>
                        <span><?php echo e($casino_dones->total_deposit); ?></span>
                    </div>
                    <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                        <h3><strong><?php echo e(__('Sign ups')); ?></strong></h3>
                        <span><?php echo e($casino_dones->total_signups); ?></span>
                    </div>
                    <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                        <h3><strong><?php echo e(__('Reloads')); ?></strong></h3>
                        <span><?php echo e($casino_dones->total_reload); ?></span>
                    </div>
                    <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                        <h3><strong><?php echo e(__('Bonus Value')); ?></strong></h3>
                        <span><?php echo e($casino_dones->total_bonus); ?></span>
                    </div>
                    <div class="shadow flex rounded justify-between items-center px-5 py-6 bg-slate-100">
                        <h3><strong><?php echo e(__('Profit')); ?></strong></h3>
                        <span><?php echo e($casino_dones->total_profit); ?></span>
                    </div>
                </div>

                <br>
                <h2 class="text-2xl mt-7 mb-2"><?php echo e(__('Last '.count($sevens).' days')); ?></h2>
                <div class="table w-full border rounded-md shadow-md">
                    <div class="table-header-group bg-slate-200">
                        <div class="table-row">
                            <div class="table-cell p-5"></div>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div class="table-cell p-3"><?php echo e(date('d-M', strtotime($single->date))); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"> <?php echo e(__('Last '.count($sevens).' days')); ?></div>
                        </div>
                    </div>
                    <div class="table-row-group">
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('Bonus Value')); ?></div>
                            <?php $total_bonus_value = 0; ?>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="table-cell p-3"><?php echo e($single->bonus_value); ?></div>
                                <?php $total_bonus_value += $single->bonus_value; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_bonus_value); ?></div>
                        </div>
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('Bonuses Done')); ?></div>
                            <?php $total_bonus_done = 0; ?>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="table-cell p-3"><?php echo e($single->bonus_done); ?></div>
                                <?php $total_bonus_done += $single->bonus_done; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_bonus_done); ?></div>
                        </div>
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('EV')); ?></div>
                            <?php $total_bonus_ev = 0; ?>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="table-cell p-3"><?php echo e($single->bonus_ev); ?></div>
                                <?php $total_bonus_ev += $single->bonus_ev; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_bonus_ev); ?></div>
                        </div>
                        <div class="table-row">
                            <div class="table-cell p-5"><?php echo e(__('Profit')); ?></div>
                            <?php $total_profit = 0; ?>
                            <?php $__currentLoopData = $sevens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <div class="table-cell p-3"><?php echo e($single->bonus_profit); ?></div>
                                <?php $total_profit += $single->bonus_profit; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="table-cell p-5"><?php echo e($total_profit); ?></div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/casinodone/summary.blade.php ENDPATH**/ ?>