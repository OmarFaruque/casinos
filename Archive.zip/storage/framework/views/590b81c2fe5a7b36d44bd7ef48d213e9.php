<?php $__env->startSection('content'); ?>
    <div class="listsconetnt content-center justify-center w-full px-6">
        <div class="grid h-full content-center justify-center px-6">
            <h2 class="text-center bold mb-5 text-2xl"><strong><?php echo e(__('New Bonus')); ?></strong></h2>
            <div class="grid w-full m-auto content-item-center h-full justify-center">
            
                <form 

                    
                    <?php if(Route::is('bonus.create')): ?>
                        action="<?php echo e(route('bonus.store')); ?>"
                    <?php else: ?> 
                        action="<?php echo e(route('bonus.update', $bonus)); ?>"
                    <?php endif; ?>   
                
                    method="post">
                    <?php if(!Route::is('bonus.create')): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="grid content-center grid-cols-3 gap-10 w-full justify-center">
                        <div class="">
                            <label for="gnome"><?php echo e(__('Gnome')); ?></label>
                            <select id="gnome" name="gnome" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('gnome') ? 'border-orange-600' : ''); ?>">
                                <option value=""><?php echo e(__('Select Gnome...')); ?></option>
                                <?php $__currentLoopData = $gnomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gnome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($bonus) && $gnome->id == $bonus->gnome ? 'selected' : ''); ?> value="<?php echo e($gnome->id); ?>"><?php echo e($gnome->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->get('gnome')): ?> <div class="text-orange-600"><small><?php echo e($errors->first('gnome')); ?></small></div> <?php endif; ?>
                        </div>

                        <div class="">
                            <label for="casino_name"><?php echo e(__('Casino Name')); ?></label>
                            <select id="casino_name" name="casino_name" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('casino_name') ? 'border-orange-600' : ''); ?>">
                                <option value=""><?php echo e(__('Select Casino...')); ?></option>
                                <?php $__currentLoopData = $casinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casino): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($bonus) && $casino->id == $bonus->casino_name ? 'selected' : ''); ?> value="<?php echo e($casino->id); ?>"><?php echo e($casino->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->get('casino_name')): ?> <div class="text-orange-600"><small><?php echo e($errors->first('casino_name')); ?></small></div> <?php endif; ?>
                        </div>
                        <div class="">
                            <label for="casino_lookup"><?php echo e(__('Casino Lookup')); ?></label>
                            <input type="text" name="casino_lookup" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('casino_lookup') ? 'border-orange-600' : ''); ?>" id="name" value="<?php echo e(isset($bonus) && $bonus->casino_lookup ? $bonus->casino_lookup : ''); ?>">
                            <?php if($errors->get('casino_lookup')): ?> <div class="text-orange-600"><small><?php echo e($errors->first('casino_lookup')); ?></small></div> <?php endif; ?>
                        </div>

                        <div class="">
                            <label for="prtn"><?php echo e(__('Prtn')); ?></label>
                            <input type="number" name="prtn" class="border rounded p-2 mr-2 w-full shadow <?php echo e($errors->get('prtn') ? 'border-orange-600' : ''); ?>" id="prtn" value="<?php echo e(isset($bonus) && $bonus->prtn ? $bonus->prtn : ''); ?>">
                        </div>

                        <div class="">
                            <label for="group"><?php echo e(__('Group')); ?></label>
                            <select id="group" name="group" class="border rounded p-2 mr-2 w-full shadow">
                                <option value=""><?php echo e(__('Select Group...')); ?></option>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($bonus) && $group->id == $bonus->group ? 'selected' : ''); ?> value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="">
                            <label for="deposit"><?php echo e(__('Deposit')); ?></label>
                            <input type="number" name="deposit" class="border rounded p-2 mr-2 w-full shadow" id="deposit" value="<?php echo e(isset($bonus) && $bonus->deposit ? $bonus->deposit : ''); ?>">
                        </div>
                        <div class="">
                            <label for="bonus"><?php echo e(__('Bonus')); ?></label>
                            <input type="number" name="bonus" class="border rounded p-2 mr-2 w-full shadow" id="bonus" value="<?php echo e(isset($bonus) && $bonus->bonus ? $bonus->bonus : ''); ?>">
                        </div>

                        <div class="">
                            <label for="wagering_name"><?php echo e(__('Wagering Type')); ?></label>
                            <select id="wagering_name" name="wagering_name" class="border rounded p-2 mr-2 w-full shadow">
                                <option value=""><?php echo e(__('Select...')); ?></option>
                                <option <?php echo e(isset($bonus) && 'xb' == $bonus->wagering_name ? 'selected' : ''); ?> value="xb">xB</option>
                                <option <?php echo e(isset($bonus) && 'xdb' == $bonus->wagering_name ? 'selected' : ''); ?> value="xdb">x(D+B)</option>
                            </select>
                        </div>

                        <div class="">
                            <label for="payment_methods"><?php echo e(__('Payment Methods')); ?></label>
                            <select id="payment_methods" multiple="multiple" name="payment_methods[]" class="border rounded p-2 mr-2 w-full shadow select2">
                                <option value=""><?php echo e(__('Select a payment...')); ?></option>
                                <?php $__currentLoopData = $p_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($bonus) && $method == $bonus->payment_methods ? 'selected' : ''); ?> value="<?php echo e($k); ?>"><?php echo e($method); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="">
                            <label for="wagering_value"><?php echo e(__('Wagering Value')); ?></label>
                            <input type="wagering_value" name="wagering_value" class="border rounded p-2 mr-2 w-full shadow" id="bonus" value="<?php echo e(isset($bonus) && $bonus->wagering_value ? $bonus->wagering_value : ''); ?>">
                        </div>

                        <div class="">
                            <label for="country_banned"><?php echo e(__('Country Banned')); ?></label>
                            <select id="country_banned" name="country_banned[]" multiple="multiple" class="border rounded p-2 mr-2 w-full shadow select2">
                                <option value=""><?php echo e(__('Select countries...')); ?></option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($bonus) && is_array($bonus->country_banned) && in_array($k, $bonus->country_banned) ? 'selected' : ''); ?> value="<?php echo e($k); ?>"><?php echo e($country); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="">
                            <label for="gnome_done_casino"><?php echo e(__('Last Time Gnome Done Casino Group')); ?></label>
                            <input type="number" min="0" name="gnome_done_casino" class="border rounded p-2 mr-2 w-full shadow" id="bonus" value="<?php echo e(isset($bonus) && $bonus->gnome_done_casino ? $bonus->gnome_done_casino : ''); ?>">
                        </div>
                        <div class="">
                            <label for="anyone_done_casino"><?php echo e(__('Last Time Anyone Done Casino')); ?></label>
                            <input type="number" min="0" name="anyone_done_casino" class="border rounded p-2 mr-2 w-full shadow" id="bonus" value="<?php echo e(isset($bonus) && $bonus->anyone_done_casino ? $bonus->anyone_done_casino : ''); ?>">
                        </div>
                        <div class="">
                            <label for="anyone_done_group"><?php echo e(__('Last Time Anyone Done Group')); ?></label>
                            <input type="number" min="0" name="anyone_done_group" class="border rounded p-2 mr-2 w-full shadow" id="bonus" value="<?php echo e(isset($bonus) && $bonus->anyone_done_group ? $bonus->anyone_done_group : ''); ?>">
                        </div>
                        <div class="">
                            <label for="gnome_pending_payout"><?php echo e(__('Pending Payouts for Gnome in this Group')); ?></label>
                            <input type="number" min="0" name="gnome_pending_payout" class="border rounded p-2 mr-2 w-full shadow" id="bonus" value="<?php echo e(isset($bonus) && $bonus->gnome_pending_payout ? $bonus->gnome_pending_payout : ''); ?>">
                        </div>
                        <div class="">
                            <label for="everyone_pending_payout"><?php echo e(__('Total Pending Payouts for Everyone for this Group')); ?></label>
                            <input type="number" min="0" name="everyone_pending_payout" class="border rounded p-2 mr-2 w-full shadow" id="bonus" value="<?php echo e(isset($bonus) && $bonus->everyone_pending_payout ? $bonus->everyone_pending_payout : ''); ?>">
                        </div>
                        <div class="">
                            <label for="everyone_sub_pending_payout"><?php echo e(__('SUB Pending Payouts for Everyone in this Group')); ?></label>
                            <input type="number" min="0" name="everyone_sub_pending_payout" class="border rounded p-2 mr-2 w-full shadow" id="bonus" value="<?php echo e(isset($bonus) && $bonus->everyone_sub_pending_payout ? $bonus->everyone_sub_pending_payout : ''); ?>">
                        </div>
                        <div class="">
                            <label for="notes"><?php echo e(__('Notes')); ?></label>
                            <input type="text" name="notes" class="border rounded p-2 mr-2 w-full shadow" id="bonus" value="<?php echo e(isset($bonus) && $bonus->notes ? $bonus->notes : ''); ?>">
                        </div>


                        <div class="flex items-end">
                            <button type="submit" class="btn justify-end py-2 hover:bg-gray-900 hover:text-gray-50 transition  border px-5 rounded-md"><?php echo e(Route::is('bonus.create') ? __('Submit') : __('Update')); ?></button>
                        </div>
                    </div>  
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/bonus/create.blade.php ENDPATH**/ ?>