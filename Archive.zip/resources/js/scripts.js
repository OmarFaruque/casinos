import $ from "jquery";

let profileMenu = document.getElementById('profileMenu');
profileMenu.addEventListener('click', function(){
    document.getElementById('dropdown-profile').classList.toggle("hidden");
});

$(document).ready(function(){
    $(document.body).on('click', '.casino-dropdown', function(){
        $(this).next('ul').slideToggle();
    });
});

