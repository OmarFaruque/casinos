import './bootstrap';
import './scripts';
import "/node_modules/select2/dist/css/select2.css";
