@extends('layouts.app-master')

@section('content')
    <div class="listsconetnt content-center justify-center w-full">
        <div class="grid h-full content-center justify-center">
            <h2 class="text-center bold mb-5">{{__('New Entry')}}</h2>
            <div class="grid w-full m-auto content-item-center h-full justify-center">
                <form action="{{route('players.store')}}" method="post">
                    @csrf
                    <div class="grid content-center grid-cols-3 gap-10 w-full justify-center">
                        <div class="">
                            <label for="name">{{__('Name')}}</label>
                            <input type="text" name="name" class="border rounded p-2 mr-2 w-full shadow" id="name" value="">
                        </div>
                        <div class="">
                            <label for="date">{{__('Date')}}</label>
                            <input type="date" name="date" class="border rounded p-2 mr-2 w-full shadow" id="date" value="">
                        </div>
                        <div class="">
                            <label for="casino_bonus_lookup">{{__('Casino Bonus Lookup')}}</label>
                            <input type="text" name="casino_bonus_lookup" class="border rounded p-2 mr-2 shadow w-full" id="casino_bonus_lookup" value="">
                        </div>
                        <div class="">
                            <label for="type">{{__('Type')}}</label>
                            
                            <select name="type" id="type" class="border rounded p-2 mr-2 shadow w-full">
                                <option value="">{{__('Type...')}}</option>
                                @foreach($types as $k => $type)
                                    <option value="{{$k}}">{{$type}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="">
                            <label for="group">{{__('Group')}}</label>
                            <input type="text" name="group" class="border rounded p-2 mr-2 shadow w-full" id="group" value="">
                        </div>
                        <div class="">
                            <label for="payment_method">{{__('Payment Method')}}</label>
                            <select class="border rounded p-2 mr-2 shadow w-full" name="payment_method" id="payment_method">
                                <option value="">{{ __('Payment Method...') }}</option>
                                @foreach($payment_methods as $s => $pmethod)
                                    <option value="{{$s}}">{{$pmethod}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="">
                            <label for="deposit">{{__('Deposit')}}</label>
                            <input type="number" name="deposit" class="border rounded p-2 mr-2 shadow w-full" id="deposit" value="">
                        </div>
                        <div class="">
                            <label for="bonus">{{__('Bonus')}}</label>
                            <input type="number" name="bonus" class="border rounded p-2 mr-2 shadow w-full" id="bonus" value="">
                        </div>
                        <div class="">
                            <label for="balance">{{__('Balance')}}</label>
                            <input type="number" name="balance" class="border rounded p-2 mr-2 shadow w-full" id="balance" value="">
                        </div>
                        <div class="">
                            <label for="status">{{__('Status')}}</label>
                            <select name="status" id="status" class="border rounded p-2 mr-2 shadow w-full" >
                                @foreach($status_lists as $k => $status)
                                <option value="{{$k}}">{{$status}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="">
                            <label for="partpaid">{{__('Part Paid')}}</label>
                            <input type="number" name="partpaid" class="border rounded p-2 mr-2 shadow w-full" id="partpaid" value="">
                        </div>
                        <div class="">
                            <label for="fainalpaid">{{__('Fainal Paid')}}</label>
                            <input type="number" name="fainalpaid" class="border rounded p-2 mr-2 shadow w-full" id="fainalpaid" value="">
                        </div>

                        <div class="">
                            {{-- {{dd($slots)}} --}}
                            <label for="game_played">{{__('Game Played')}}</label>
                            <select name="game_played" id="game_played" class="border rounded p-2 mr-2 shadow w-full">
                                <option value="">{{ __('Select a slot')}}</option>
                                @foreach($slots as $k => $slot)
                                    <option value="{{ $slot->id }}">{{ $slot->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="">
                            <label for="spin">{{__('Spin')}}</label>
                            <input type="number" name="spin" class="border rounded p-2 mr-2 shadow w-full" id="spin" value="">
                        </div>

                        <div class="">
                            <label for="rtp">{{__('RTP (%)')}}</label>
                            <input type="number" name="rtp" class="border rounded p-2 mr-2 shadow w-full" id="rtp" min="0" max="100" value="">
                        </div>

                        <div class="">
                            <label for="worker">{{__('Worker')}}</label>
                            <select name="worker" id="worker" class="border rounded p-2 mr-2 shadow w-full" >
                                <option value="">{{ __('Select a Worker') }}</option>
                                @foreach($workers as $worker)
                                    <option value="{{ $worker->id }}">{{$worker->name}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-span-2">
                            <label for="notes">{{__('Notes')}}</label>
                            <input type="text" name="notes" class="border rounded p-2 mr-2 shadow w-full" id="notes" value="">
                        </div>
                    </div>
                </form>
            </div>
            @if ($errors->any())
                @foreach ($errors->all() as $error)
                    <div class="text-center w-full mt-3 text-red-500"><small>{{$error}}</small></div>
                @endforeach
            @endif
        </div>
    </div>
@endsection