@extends('layouts.app-master')

@section('content')
    <div class="listsconetnt w-full px-5 py-8">
        <a class="bg-gray-200 py-3 px-5 rounded text-gray-900 hover:text-gray-200 hover:bg-gray-900" href="{{route('new-casino-done')}}">{{ __('New Entry') }}</a>

        <div class="w-2/4 m-auto mt-9 justify-center">
            <table class="table-auto w-full rounded-md">
                <thead class="bg-gray-50 border-b-2 border-gray-200">
                    <tr class="border-bottom">
                        <th class="p-2 text-left">SL</th>
                        <th class="text-left p-2">{{ __('Name') }}</th>
                        <th class="text-left p-2">{{ __('Action') }}</th>
                    </tr>
                    <tbody>
                         
                    </tbody>
                </thead>
    
            </table>
        </div>
    </div>

   
@endsection