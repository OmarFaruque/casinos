<?php

namespace App\Http\Controllers;

use App\Models\Slot;
use App\Models\Workers;
use Illuminate\Http\Request;

class PlayersController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('casinodone.lists');
    }



    /**
     * List of all available payment methods
     * 
     * @return array
     */
    protected function payment_methods(){
        return array(
            'btc' => 'btc', 
            'icard' => 'icard', 
            'visa' => 'visa', 
            'astro' => 'astro', 
            'flex' => 'flex', 
            'mb' => 'mb', 
            'cashlib' => 'cashlib', 
            'jeton' => 'jeton'
        );
    }

    /**
     * Status Lists
     */
    protected function status_lists(){
        return array(
            'all-paid' => __('All Paid'), 
            'running'=> __('Running'), 
            'to-do' => __('To Do'), 
            'lost' => __('Lost'), 
            'pending-payout' => __('Pending Payout'), 
            'failed' => __('Failed'), 
            'running-liz' => __('Running - Liz'), 
            'running-toby' => __('Running - Toby')
        );
    }

    /**
     * Get All Workers
     */
    protected function all_workers(){
        return Workers::all();
    }

    /**
     * Get All Slots
     */
    protected function all_slots(){
        return Slot::get(['id', 'name']);
    }


    /**
     * Get all types
     * 
     * @return array
     */
    protected function all_types(){
        return array(
            'sub' => 'SUB', 
            'reload' => 'Reload', 
            'cb' => 'CB'
        );
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('casinodone.create')->with([
            'status_lists' => $this->status_lists(), 
            'workers' => $this->all_workers(), 
            'slots' => $this->all_slots(), 
            'payment_methods' => $this->payment_methods(), 
            'types' => $this->all_types()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
