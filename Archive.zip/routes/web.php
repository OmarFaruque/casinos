<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PlayersController;
use App\Http\Controllers\WorkersController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(['namespace' => 'App\Http\Controllers'], function()
{   
    /**
     * Home Routes
     */
    Route::get('/', 'HomeController@index')->name('home.index');

    Route::group(['middleware' => ['guest']], function() {
        /**
         * Register Routes
         */
        Route::get('/register', 'RegisterController@show')->name('register.show');
        Route::post('/register', 'RegisterController@register')->name('register.perform');

        /**
         * Login Routes
         */
        Route::get('/login', 'LoginController@show')->name('login.show');
        Route::post('/login', 'LoginController@login')->name('login.perform');

    });

    Route::group(['middleware' => ['auth']], function() {
        /**
         * Logout Routes
         */
        Route::get('/logout', 'LogoutController@perform')->name('logout.perform');

        /**
         * Workers resource 
         */
        Route::resource('workers', WorkersController::class);

        /**
         * Casinos done resources
         */
        Route::get('casinos-done', 'PlayersController@index')->name('casinos-done');
        Route::get('new-casino-done', 'PlayersController@create')->name('new-casino-done');
        Route::post('players.store', 'PlayersController@store')->name('players.store');

        /**
         * Slots Route
         */
        Route::resource('slot', SlotController::class);

        /**
         * Slots Route
         */
        Route::resource('gnomeinfo', GnomeinfoController::class);
    });
    
});